package cs3500.animator.controller;

import java.awt.event.ActionEvent;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JTextField;
import javax.swing.JCheckBox;
import javax.swing.JOptionPane;

import cs3500.animator.model.AnimatorModelOperations;
import cs3500.animator.model.shapes.ShapeOperations;
import cs3500.animator.view.visual.InteractiveViewOperations;

/**
 * This class is used to control any interactive animation view.
 */
public class Controller implements ControllerOperations {

  private AnimatorModelOperations model;
  private InteractiveViewOperations view;
  private Map<ShapeOperations, Integer> removedShapes;
  private Map<String, ShapeOperations> removedShapeNames;
  private String svgLocation;

  /**
   * This method is used to tell if a button has been pressed.
   * @param e The action event we are checking for action from.
   */
  @Override
  public void actionPerformed(ActionEvent e) {

    switch (e.getActionCommand()) {
      case "PLAY":
        this.playClick();
        break;
      case "PAUSE":
        this.pauseClick();
        break;
      case "RESET":
        this.stopClick();
        break;
      case "LOOP":
        this.loopClick();
        break;
      case "SVG":
        this.svgClick();
        break;
      case "SVG FIELD":
        if (e.getSource() instanceof JTextField) {
          JTextField tf = (JTextField) e.getSource();
          svgLocation = tf.getText();
        }
        break;
      case "SPEED UP":
        this.speedUpClick();
        break;
      case "SPEED":
        if (e.getSource() instanceof JTextField) {
          JTextField tf = (JTextField) e.getSource();
          this.setViewTempo(tf.getText());
        }
        break;
      case "SLOW DOWN":
        this.slowDownClick();
        break;
      default:
        if (e.getSource() instanceof JCheckBox) {
          JCheckBox cb = (JCheckBox) e.getSource();
          this.shapeSelected(e.getActionCommand(), cb.isSelected());
        }
        break;
    }
  }

  /**
   * This method is used to add the model.
   * @param m the model we are adding to our controller.
   */
  public void addModel(AnimatorModelOperations m) {
    this.model = m;
  }

  /**
   * This method is used to add the view.
   * @param v the view we are adding to our controller.
   */
  public void addView(InteractiveViewOperations v) {
    this.view = v;
    this.view.setActionListener(this);
  }

  /**
   * This method is used to start the animator.
   * @param tempo the tempo we are running at.
   */
  public void startAnimator(int tempo) {
    this.svgLocation = "";
    this.removedShapes = new HashMap<>();
    this.removedShapeNames = new HashMap<>();
    this.view.playAnimation(tempo, this.model.getState());
  }

  /**
   * This method is used to add and remove shapes while the animation is running.
   * @param shapeName the shape we are adding or removing.
   * @param isSelected is the check box selected or not.
   */
  private void shapeSelected(String shapeName, boolean isSelected) {

    if (!isSelected) {
      ShapeOperations shapeToBeRemoved = this.model.getShape(shapeName);
      int index = this.model.getState().indexOf(shapeToBeRemoved);
      this.model.removeShape(shapeToBeRemoved.getName());
      this.view.playAnimation(view.getTempo(), model.getState());
      this.removedShapes.put(shapeToBeRemoved, index);
      this.removedShapeNames.put(shapeToBeRemoved.getName(), shapeToBeRemoved);
    }
    else if (!model.contains(shapeName)) {
      for (int i = 0; i < removedShapes.size(); i++) {
        ShapeOperations shapeToBeAdded = removedShapeNames.get(shapeName);
        int index = removedShapes.get(shapeToBeAdded);
        model.addShape(shapeToBeAdded, index);
        this.view.playAnimation(view.getTempo(), model.getState());
        removedShapes.remove(shapeToBeAdded);
        removedShapeNames.remove(shapeName);
        break;
      }
    }
  }

  /**
   * This method is used to export the svg file.
   */
  private void svgClick() {
    PrintStream out;

    String fileType;
    if (svgLocation.length() > 5) {
      fileType = this.svgLocation.substring(svgLocation.length() - 4, svgLocation.length());
    }
    else {
      fileType = "";
    }

    try {
      if (fileType.equals(".svg")) {
        out = new PrintStream(new FileOutputStream(this.svgLocation));
      }
      else {
        throw new IllegalArgumentException();
      }
    }
    catch (FileNotFoundException e) {
      JOptionPane.showMessageDialog(null,
              "SVG Export Failed! Illegal Location \"" + svgLocation + "\". " +
                      "Location must be a valid file.", "SVG Export Failed",
              JOptionPane.ERROR_MESSAGE);
      return;
    }
    catch (IllegalArgumentException e) {
      JOptionPane.showMessageDialog(null,
              "SVG Export Failed! Must be an svg file (end in .svg!) " +
                      "Location must be a valid file.", "SVG Export Failed",
              JOptionPane.ERROR_MESSAGE);
      return;
    }

    Appendable ap = out;
    try {
      ap.append(this.view.getSVG(this.view.getTempo(), this.model.getState(), 800, 800));
    } catch (IOException e) {
      System.err.println("caught IOException: " + e.getMessage());
    }
    JOptionPane.showMessageDialog(null, "File exported to SVG.\nLocation: " +
                    this.svgLocation,
            "Animator", JOptionPane.INFORMATION_MESSAGE);
  }

  /**
   * This method is used to loop or not loop the animation.
   */
  private void loopClick() {
    this.view.loop();
  }

  /**
   * This method is used to pause the view.
   */
  private void stopClick() {
    this.view.reset();
  }

  /**
   * This method is used to change the tempo of the view.
   * @param tempo the tempo we want to change the view to.
   */
  private void setViewTempo(String tempo) {
    int viewTempo = Integer.parseInt(tempo);
    this.view.setTempo(viewTempo);
  }

  /**
   * This method is used to increase the tempo of the view.
   */
  private void speedUpClick() {
    this.view.setTempo(this.view.getTempo() + 1);
  }

  /**
   * This method is used to decrease the tempo of the view.
   */
  private void slowDownClick() {
    if (this.view.getTempo() > 1) {
      this.view.setTempo(this.view.getTempo() - 1);
    }
  }

  /**
   * This method is used to play the view.
   */
  private void playClick() {
    this.view.play();
  }

  /**
   * This method is used to pause the model.
   */
  private void pauseClick() {
    this.view.pause();
  }

}
