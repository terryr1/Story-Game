package cs3500.animator.view.visitors;

import cs3500.animator.model.animations.IColorAnimation;
import cs3500.animator.model.animations.IMoveAnimation;
import cs3500.animator.model.animations.IScaleAnimation;
import cs3500.animator.view.animations.AnimationViewOperations;
import cs3500.animator.view.animations.ViewColorAnimation;
import cs3500.animator.view.animations.ViewMoveAnimation;
import cs3500.animator.view.animations.ViewScaleAnimation;

/**
 * Used to build view animations from regular animations.
 */
public class ViewAnimationVisitor implements AnimationVisitor<AnimationViewOperations> {

  /**
   * Create a view move animation from the given move animation.
   * @param move the move animation we are adding functionality to.
   * @return the new view move animation.
   */
  @Override
  public AnimationViewOperations visit(IMoveAnimation move) {
    return new ViewMoveAnimation(move.getFrom(), move.getTo(), move.getFromTime(),
            move.getToTime());
  }

  /**
   * Create a view scale animation from the given scale animation.
   * @param scale the scale animation we are adding functionality to.
   * @return the new view scale animation.
   */
  @Override
  public AnimationViewOperations visit(IScaleAnimation scale) {
    return new ViewScaleAnimation(scale.getFrom(), scale.getTo(), scale.getFromTime(),
            scale.getToTime());
  }

  /**
   * Create a view color animation from the given color animation.
   * @param changeColor the color animation we are adding functionality to.
   * @return the new view color animation.
   */
  @Override
  public AnimationViewOperations visit(IColorAnimation changeColor) {
    return new ViewColorAnimation(changeColor.getFrom(), changeColor.getTo(),
            changeColor.getFromTime(), changeColor.getToTime());
  }

}
