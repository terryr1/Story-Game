package cs3500.animator.provider.model;

import java.util.HashMap;

/**
 * Represents the functionality of an AnimatorModel.
 */
public interface IAnimatorModel {

  /**
   * Adds a shape to the animation. TODO: this should probably return (copy of?) this.shapes
   * @param name name of the shape
   * @param shape the shape
   * @param appearsAt time the shape appears
   * @param disappearsAt time the shape disappears
   */
  void addShape(String name, IShape shape, int appearsAt, int disappearsAt);

  /**
   * Adds a transition to the specified shape.
   * @param name the name of the shape
   * @param transition the transition to add
   * @throws IllegalArgumentException if shape is not in this cs3500.animator.model or
   *         transition cannot be added without conflicting with an existing one.
   */
  void addTransition(String name, ITransition transition);

  /**
   * Returns a copy of the shapes in this model.
   * @return the shapes
   */
  HashMap<String, IShape> getShapes();
}
