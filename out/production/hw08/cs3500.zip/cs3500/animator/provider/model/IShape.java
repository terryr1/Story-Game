package cs3500.animator.provider.model;

import java.util.List;

/**
 * Represents the functionality of a Shape.
 */
public interface IShape {

  /**
   * Mutates this shape to reflect its state at the given time
   * as determined by its transitions.
   *
   * @param time the time of this state's transition
   */
  void stateAt(int time);

  /**
   * Adds a new transition to this shape's list of transitions.
   * @param transition the transition to add
   */
  void addTransition(ITransition transition);

  /**
   * Sets the time frame when this shape is visible.
   * @param start the start time
   * @param done the disappear time
   */
  void setTimeWindow(int start, int done);

  /**
   * Updates this shape's Color.
   * @param c the new Color
   */
  void updateColor(Color c);

  /**
   * Updates this shape's position.
   * @param p the new position
   */
  void updatePosition(Posn p);

  /**
   * Updates a dimension of this shape.
   * @param name the name of the dimension
   * @param val the value of the dimension
   * @throws IllegalArgumentException if name is null or value is negative
   */
  void updateDimension(String name, double val);

  /**
   * Gets the type of this shape. (i.e. "Rectangle", "Oval", etc.)
   * @return Shapes enum representing this shape's type
   */
  Shapes getType();

  /**
   * Returns a copy of this shape's position.
   * @return the posn
   */
  IPosn getPosition();

  /**
   * Gets the value of the x dimension of this shape.
   * @return the double that is the value of the x dimension of this shape.
   */
  double getXLength();

  /**
   * Gets the value of the y dimension of this shape.
   * @return the double that is the value of the y dimension of this shape
   */
  double getYLength();

  /**
   * Gets the color of this shape.
   */
  Color getColor();

  /**
   * Gets the tick value of when this shape appears.
   */
  int getStartTime();

  /**
   * Gets the tick value of when this shape disappears.
   */
  int getEndTime();

  /**
   * Gets the transitions of this shape.
   * @return the transitions of this shape.
   */
  List<ITransition> getTransitions();

  /**
   * Returns string representation of this shape.
   * @return the string rep. of this shape
   */
  @Override
  String toString();

  /**
   * Sets the amount to scale time by for this shape.
   * @param scalarToRealTime sets the amount of time to scale time by for this shape.
   */
  void setScalarToRealTime(double scalarToRealTime);

  /**
   * Summarizes the effect of this shape's transitions.
   * @return list of string statements, in chronological order according to when transition occurs
   */
  List<String> transitionSummary();

  /**
   * Adds a scale transition to this shape's list of transitions.
   * Transition details are only known within each implementing class.
   *
   * @param oldX original x-value of posn
   * @param newX new x-value of posn
   * @param oldY old y-value of posn
   * @param newY new y-value of posn
   * @param startTime start time of the transition
   * @param endTime end time of the transition
   */
  void addRelevantSizeTransition(double oldX, double oldY, double newX, double newY,
                                 int startTime, int endTime);

  /**
   * The types a shape can be.
   */
  public enum Shapes {
    RECTANGLE, OVAL
  }
}
