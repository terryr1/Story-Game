package cs3500.animator.provider.model;

/**
 * Represents the functionality of a ColorTransition.
 */
public interface IColorTransition extends ITransition {

  /**
   * Returns the starting color of this transition.
   * @return the color
   */
  IColor getFromColor();

  /**
   * Returns the ending color of this transition.
   * @return the color
   */
  IColor getToColor();

}
