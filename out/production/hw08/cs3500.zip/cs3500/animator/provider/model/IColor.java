package cs3500.animator.provider.model;

public interface IColor {

  /**
   * Gets the red value of this color.
   * @return red value
   */
  double getRed();

  /**
   * Gets the green value of this color.
   * @return green value
   */
  double getGreen();

  /**
   * Gets the blue value of this color.
   * @return blue value
   */
  double getBlue();

}
