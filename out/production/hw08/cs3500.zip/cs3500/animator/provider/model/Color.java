package cs3500.animator.provider.model;

/**
 * Represents a Color based on a red, green, and blue value.
 */
public class Color implements IColor {
  private final double red;
  private final double green;
  private final double blue;

  /**
   * Constructs a color based on the given rgb values.
   * @param r red value
   * @param g green value
   * @param b blue value
   * @throws IllegalArgumentException if values for RGB are invalid
   */
  public Color(double r, double g, double b) {
    if (r < 0 || r > 255 || g < 0 || g > 255 || b < 0 || b > 255) {
      throw new IllegalArgumentException("RGB values must be between [0, 255].");
    }

    this.red = r;
    this.green = g;
    this.blue = b;
  }

  /**
   * Gets the red value of this color.
   * @return red value
   */
  public double getRed() {
    return this.red;
  }

  /**
   * Gets the green value of this color.
   * @return green value
   */
  public double getGreen() {
    return this.green;
  }

  /**
   * Gets the blue value of this color.
   * @return blue value
   */
  public double getBlue() {
    return this.blue;
  }

}
