package cs3500.animator.provider.model;

/**
 * Represents the functionality of a size transition.
 */
public interface ISizeTransition extends ITransition {

  /**
   * Returns the name of the dimension that is being re-sized.
   * @return the dimension name
   */
  String getDimensionName();

  /**
   * Gets the original value of the dimension being re-sized.
   * @return the value
   */
  double getStartValue();

  /**
   * Gets the new value of the dimension being re-sized.
   * @return the value
   */
  double getEndValue();
}
