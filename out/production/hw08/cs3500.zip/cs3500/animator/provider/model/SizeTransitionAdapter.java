package cs3500.animator.provider.model;

import java.util.ArrayList;

import cs3500.animator.model.animations.IScaleAnimation;
import cs3500.animator.model.shapes.IDimension;

/**
 * This class is used to adapt a ScaleAnimation to a SizeTransition.
 */
public class SizeTransitionAdapter extends AnimationAdapter implements ISizeTransition {

  private int dimNum;

  /**
   * Constructs this sizeTransition.
   * @param anim the ScaleAnimation we are adapting to be a SizeTransitionAdapter.
   * @param realTimeScalar a scalar needed for our toString.
   * @param shapeName the name of the shape we are changing, needed for the toString.
   * @param dimNum the dimension index we want to change in this adapter.
   */
  public SizeTransitionAdapter(IScaleAnimation anim, double realTimeScalar, String shapeName,
                               int dimNum) {
    super(anim, realTimeScalar, shapeName);
    this.dimNum = dimNum;
  }

  /**
   * Gets the enum type of this transition.
   * @return the type
   */
  @Override
  public Transitions getType() {
    return Transitions.RESIZE;
  }

  /**
   * Returns the name of the dimension that is being re-sized.
   * @return the dimension name.
   */
  @Override
  public double getStartValue() {
    ArrayList<IDimension> dims = anim.getFrom();

    return (double)dims.get(dimNum).getValue();
  }

  /**
   * Gets the new value of the dimension being re-sized.
   * @return the value
   */
  @Override
  public double getEndValue() {
    ArrayList<IDimension> dims = anim.getTo();
    return (double) dims.get(dimNum).getValue();
  }

  /**
   * Returns the name of the dimension that is being re-sized.
   * @return the dimension name
   */
  @Override
  public String getDimensionName() {
    ArrayList<IDimension> dims = anim.getTo();

    return dims.get(dimNum).getType();
  }

}
