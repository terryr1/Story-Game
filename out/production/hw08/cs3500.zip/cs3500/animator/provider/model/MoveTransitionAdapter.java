package cs3500.animator.provider.model;

import cs3500.animator.model.animations.IMoveAnimation;

/**
 * This class is used to adapt a MoveAnimation to a MoveTransition.
 */
public class MoveTransitionAdapter extends AnimationAdapter implements IMoveTransition {

  /**
   * Constructs a MoveTransitionAdapter.
   * @param anim The MoveAnimation we want to adapt.
   * @param realTimeScalar A scalar value we need for the toString method.
   * @param shapeName The name of the shape we are animation, also for the toString.
   */
  public MoveTransitionAdapter(IMoveAnimation anim, double realTimeScalar, String shapeName) {
    super(anim, realTimeScalar, shapeName);
  }

  /**
   * Gets the enum type of this transition.
   * @return the type
   */
  @Override
  public Transitions getType() {
    return Transitions.MOVE;
  }

  /**
   * Returns the original position of this transition.
   * @return the position
   */
  @Override
  public IPosn getFromPosn() {
    cs3500.animator.model.shapes.IPosn prevPosn = anim.getFrom();
    return new Posn(prevPosn.getX(), prevPosn.getY());
  }

  /**
   * Returns the ending position of this transition.
   * @return the position
   */
  @Override
  public IPosn getToPosn() {
    cs3500.animator.model.shapes.IPosn prevPosn = anim.getTo();
    return new Posn(prevPosn.getX(), prevPosn.getY());
  }

}
