package cs3500.animator.provider.model;

/**
 * Interface for all shape transformations.
 */
public interface ITransition {

  /**
   * All the types of transitions that implement this interface.
   */
  enum Transitions {
    MOVE, COLOR, RESIZE
  }

  /**
   * Gets the enum type of this transition.
   * @return the type
   */
  Transitions getType();

  /**
   * Executes this transition on the given shape based on the given time.
   * @param time the current time at this execution
   * @param shape the shape to mutate
   */
  void execute(int time, IShape shape);

  /**
   * Summarizes this transition's effect on the shape.
   * @return string with summary
   */
  String effectSummary(double scalarToRealTime);

  /**
   * Checks whether this transition would conflict with given transition
   * if added to the same shape.
   * @param t the other transition
   * @return boolean, true if conflict exists.
   */
  boolean conflictsWith(ITransition t);

  /**
   * Returns the time of this transition's start.
   * @return int start time
   */
  int getStartTime();

  /**
   * Returns the time of this transition's end.
   * @return int end time
   */
  int getEndTime();

}
