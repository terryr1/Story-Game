package cs3500.animator.provider.model;

import cs3500.animator.model.animations.IColorAnimation;

/**
 * This class is used to adapt an IColorAnimation to an IColorTransition.
 */
public class ColorTransitionAdapter extends AnimationAdapter implements IColorTransition {

  /**
   * Used to construct our ColorTransitionAdapter.
   * @param anim the IColorAnimation we are adapting to an IColorTransition.
   * @param realTimeScalar a scalar value needed for the toString method.
   * @param shapeName the name of the shape we are animation, also needed for the toString.
   */
  public ColorTransitionAdapter(IColorAnimation anim, double realTimeScalar, String shapeName) {
    super(anim, realTimeScalar, shapeName);
  }

  /**
   * Gets the enum type of this transition.
   * @return the type
   */
  @Override
  public Transitions getType() {
    return Transitions.COLOR;
  }

  /**
   * Returns the starting color of this transition.
   * @return the color
   */
  @Override
  public IColor getFromColor() {
    java.awt.Color c = anim.getFrom();
    return new Color(c.getRed(), c.getGreen(), c.getBlue());
  }

  /**
   * Returns the ending color of this transition.
   * @return the color
   */
  @Override
  public IColor getToColor() {
    java.awt.Color c = anim.getTo();
    return new Color(c.getRed(), c.getGreen(), c.getBlue());
  }

}
