package cs3500.animator.provider.model;

/**
 * Represents a position on the XY Plane.
 */
public class Posn implements IPosn {
  private double x;
  private double y;

  /**
   * Used to construct a Posn.
   * @param x the x value of this Posn.
   * @param y the y value of this Posn.
   */
  public Posn(double x, double y) {
    this.x = x;
    this.y = y;
  }

  /**
   * Gets the x value of this Posn.
   * @return the x value of this Posn.
   */
  @Override
  public double getX() {
    return this.x;
  }

  /**
   * Gets the y value of this Posn.
   * @return the y value of this Posn.
   */
  @Override
  public double getY() {
    return this.y;
  }

  /**
   * Gets this Posn as a String.
   * @return  returns this Posn as a String.
   */
  @Override
  public String toString() {
    return "(" + this.x + "," + this.y + ")";
  }
}
