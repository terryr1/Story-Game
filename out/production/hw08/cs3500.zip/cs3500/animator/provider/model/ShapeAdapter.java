package cs3500.animator.provider.model;

import java.util.ArrayList;
import java.util.List;
import cs3500.animator.model.animations.AnimationOperations;
import cs3500.animator.model.animations.ColorAnimation;
import cs3500.animator.model.animations.MoveAnimation;
import cs3500.animator.model.animations.ScaleAnimation;
import cs3500.animator.model.shapes.ShapeOperations;

/**
 * This class is used to adapt a ShapeOperations object to an IShape.
 */
public class ShapeAdapter implements IShape {

  private ShapeOperations shape;
  private double realTimeScalar;
  private int curTick;

  /**
   * Used to construct our ShapeAdapter.
   * @param shape the shape we are adapting into an IShape.
   */
  public ShapeAdapter(ShapeOperations shape) {
    this.shape = shape;
    this.realTimeScalar = 1;
    curTick = 0;
  }

  /**
   * Mutates this shape to reflect its state at the given time
   * as determined by its transitions.
   *
   * @param time the time of this state's transition
   */
  @Override
  public void stateAt(int time) {
    this.curTick = time;

    shape.animate(time);
  }

  /**
   * Adds a new transition to this shape's list of transitions.
   * @param transition the transition to add
   */
  @Override
  public void addTransition(ITransition transition) {
    throw new UnsupportedOperationException("This operation is not needed");
  }

  /**
   * Sets the time frame when this shape is visible.
   * @param start the start time
   * @param done the disappear time
   */
  @Override
  public void setTimeWindow(int start, int done) {
    throw new UnsupportedOperationException("This operation is not needed");
  }

  /**
   * Updates this shape's Color.
   * @param c the new Color
   */
  @Override
  public void updateColor(Color c) {
    throw new UnsupportedOperationException("This operation is not needed");
  }

  /**
   * Updates this shape's position.
   * @param p the new position
   */
  @Override
  public void updatePosition(Posn p) {
    throw new UnsupportedOperationException("This operation is not needed");
  }

  /**
   * Updates a dimension of this shape.
   * @param name the name of the dimension
   * @param val the value of the dimension
   * @throws IllegalArgumentException if name is null or value is negative
   */
  @Override
  public void updateDimension(String name, double val) {
    throw new UnsupportedOperationException("This operation is not needed");
  }

  /**
   * Gets the type of this shape. (i.e. "Rectangle", "Oval", etc.)
   * @return Shapes enum representing this shape's type
   */
  @Override
  public Shapes getType() {
    return shape.accept(new ShapeTypeVisitor());
  }

  /**
   * Returns a copy of this shape's position.
   * @return the posn
   */
  @Override
  public IPosn getPosition() {
    return new Posn(shape.getPosition().getX(), shape.getPosition().getY());
  }

  /**
   * Gets the value of the x dimension of this shape.
   * @return the double that is the value of the x dimension of this shape.
   */
  @Override
  public double getXLength() {

    if (shape.getAppearTime() <= curTick && shape.getDisappearTime() >= curTick) {
      return shape.getDimensions().get(0).getValue();
    }
    else {
      return 0;
    }
  }

  /**
   * Gets the value of the y dimension of this shape.
   * @return the double that is the value of the y dimension of this shape
   */
  @Override
  public double getYLength() {
    return shape.getDimensions().get(1).getValue();
  }

  /**
   * Gets the color of this shape.
   */
  @Override
  public Color getColor() {
    return new Color(shape.getColor().getRed(), shape.getColor().getGreen(),
            shape.getColor().getBlue());
  }

  /**
   * Gets the tick value of when this shape appears.
   */
  @Override
  public int getStartTime() {
    return (int) shape.getAppearTime();
  }

  /**
   * Gets the tick value of when this shape disappears.
   */
  @Override
  public int getEndTime() {
    return (int) shape.getDisappearTime();
  }

  /**
   * Gets the transitions of this shape.
   * @return the transitions of this shape.
   */
  @Override
  public List<ITransition> getTransitions() {
    this.stateAt(0);

    ArrayList<AnimationOperations> shapeAnims = shape.getAnimations();
    List<ITransition> transitions = new ArrayList<>();

    for (AnimationOperations a : shapeAnims) {
      ITransition newt = a.accept(new TransitionVisitor(realTimeScalar, shape.getName(), 0));
      if (newt.getType() == ITransition.Transitions.RESIZE) {
        for (int i = 0; i < shape.getDimensions().size(); i++) {
          transitions.add(a.accept(new TransitionVisitor(realTimeScalar, shape.getName(), i)));
        }
      }
      else {
        transitions.add(newt);
      }
    }

    transitions.add(new SizeTransitionAdapter(new ScaleAnimation(shape.getDimensions(),
            shape.getDimensions(), shape.getAppearTime(), shape.getAppearTime()), realTimeScalar,
            shape.getName(), 0));
    transitions.add(new SizeTransitionAdapter(new ScaleAnimation(shape.getDimensions(),
            shape.getDimensions(), shape.getAppearTime(), shape.getAppearTime()), realTimeScalar,
            shape.getName(), 1));
    transitions.add(new MoveTransitionAdapter(new MoveAnimation(shape.getPosition(),
            shape.getPosition(), shape.getAppearTime(), shape.getAppearTime()), realTimeScalar,
            shape.getName()));
    transitions.add(new ColorTransitionAdapter(new ColorAnimation(shape.getColor(),
            shape.getColor(), shape.getAppearTime(), shape.getAppearTime()), realTimeScalar,
            shape.getName()));

    return transitions;
  }

  /**
   * Sets the amount to scale time by for this shape.
   * @param scalarToRealTime sets the amount of time to scale time by for this shape.
   */
  @Override
  public void setScalarToRealTime(double scalarToRealTime) {
    this.realTimeScalar =  scalarToRealTime;
  }

  /**
   * Summarizes the effect of this shape's transitions.
   * @return list of string statements, in chronological order according to when transition occurs
   */
  @Override
  public List<String> transitionSummary() {
    List<String> transitions = new ArrayList();

    for (ITransition t : this.getTransitions()) {
      transitions.add(t.toString());
    }

    return transitions;
  }

  /**
   * Adds a scale transition to this shape's list of transitions.
   * Transition details are only known within each implementing class.
   *
   * @param oldX original x-value of posn
   * @param newX new x-value of posn
   * @param oldY old y-value of posn
   * @param newY new y-value of posn
   * @param startTime start time of the transition
   * @param endTime end time of the transition
   */
  @Override
  public void addRelevantSizeTransition(double oldX, double oldY, double newX, double newY,
                                        int startTime, int endTime) {
    throw new UnsupportedOperationException("This operation is not needed.");
  }

  /**
   * Returns string representation of this shape.
   * @return the string rep. of this shape
   */
  @Override
  public String toString() {
    String output = shape.toString();
    output = output.replaceAll("Appears at t=" + shape.getAppearTime(),
            "Appears at t=" + shape.getAppearTime() * realTimeScalar + "s");
    output = output.replaceAll("Disappears at t=" + shape.getDisappearTime(),
            "Disappears at t=" + shape.getDisappearTime() * realTimeScalar + "s");
    output = output.replaceAll("Name: " + shape.getName() + "\n", "");
    return output;
  }
}
