package cs3500.animator.provider.model;

import cs3500.animator.model.animations.AnimationOperations;

/**
 * This class is used to adapt a AnimationOperations to ITransition.
 */
public abstract class AnimationAdapter implements ITransition {

  AnimationOperations anim;
  private double realTimeScalar;
  protected String animatedShapeName;

  /**
   * The constructor for our AnimationAdapter.
   * @param anim the AnimationOperations we want to adapt to an ITransition.
   * @param realTimeScalar a scalar value needed for the toString method, used to scale ticks to
   *                       time.
   * @param animatedShapeName the name of the shape we are animating, used in the toString.
   */
  AnimationAdapter(AnimationOperations anim, double realTimeScalar, String animatedShapeName) {
    this.anim = anim;
    this.realTimeScalar = realTimeScalar;
    this.animatedShapeName = animatedShapeName;
  }

  /**
   * Executes this transition on the given shape based on the given time.
   * @param time the current time at this execution
   * @param shape the shape to mutate
   */
  @Override
  public void execute(int time, IShape shape) {
    throw new UnsupportedOperationException("This operation is not needed.");
  }

  /**
   * Summarizes this transition's effect on the shape.
   * @return string with summary
   */
  @Override
  public String effectSummary(double scalarToRealTime) {
    throw new UnsupportedOperationException("This operation is not needed.");
  }

  /**
   * Checks whether this transition would conflict with given transition
   * if added to the same shape.
   * @param t the other transition
   * @return boolean, true if conflict exists.
   */
  @Override
  public boolean conflictsWith(ITransition t) {
    throw new UnsupportedOperationException("This operation is not needed.");
  }

  /**
   * Returns the time of this transition's start.
   * @return int start time
   */
  @Override
  public int getStartTime() {
    return (int)anim.getFromTime();
  }

  /**
   * Returns the time of this transition's end.
   * @return int end time
   */
  @Override
  public int getEndTime() {
    return (int)anim.getToTime();
  }

  /**
   * Returns string representation of this transition.
   * @return the string rep. of this transition.
   */
  @Override
  public String toString() {
    String output = anim.toString();
    output = output.replaceAll("" + anim.getFromTime(),
            "" + anim.getFromTime() * realTimeScalar + "s");
    output = output.replaceAll("" + anim.getToTime(),
            "" + anim.getToTime() * realTimeScalar + "s");
    output = output.replaceAll("Shape " + this.animatedShapeName + " ", "");
    return output;
  }

}
