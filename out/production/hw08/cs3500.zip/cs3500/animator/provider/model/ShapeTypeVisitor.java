package cs3500.animator.provider.model;

import cs3500.animator.model.shapes.IOval;
import cs3500.animator.model.shapes.IRectangle;
import cs3500.animator.view.visitors.ShapeVisitor;

/**
 * This class is used to get the type of the Shape as an ENUM.
 */
public class ShapeTypeVisitor implements ShapeVisitor<IShape.Shapes> {

  /**
   * This method is used to return a rectangle as an enum RECTANGLE.
   * @param rect the rectangle we are adding functionality to.
   * @return the enum RECTANGLE.
   */
  @Override
  public IShape.Shapes visit(IRectangle rect) {
    return IShape.Shapes.RECTANGLE;
  }

  /**
   * This method is used to return a rectangle as an enum OVAL.
   * @param oval the rectangle we are adding functionality to.
   * @return the enum OVAL.
   */
  @Override
  public IShape.Shapes visit(IOval oval) {
    return IShape.Shapes.OVAL;
  }
}
