package cs3500.animator.provider.model;

/**
 * Represents the functionality of a Posn.
 */
public interface IPosn {

  /**
   * Gets the x value of this IPosn.
   * @return the x value.
   */
  double getX();

  /**
   * Gets the y value of this IPosn.
   * @return the y value.
   */
  double getY();

  /**
   * Returns this Posn as a String.
   * @return  this Posn as a String.
   */
  String toString();

}

