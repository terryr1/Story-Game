package cs3500.animator.provider.model;

/**
 * Represents the functionality of a MoveTransition.
 */
public interface IMoveTransition extends ITransition {

  /**
   * Returns the original position of this transition.
   * @return the position
   */
  public IPosn getFromPosn();

  /**
   * Returns the ending position of this transition.
   * @return the position
   */
  public IPosn getToPosn();

}
