package cs3500.animator.provider.model;

import cs3500.animator.model.animations.IColorAnimation;
import cs3500.animator.model.animations.IMoveAnimation;
import cs3500.animator.model.animations.IScaleAnimation;
import cs3500.animator.view.visitors.AnimationVisitor;

/**
 * This visitor is used to adapt an AnimationOperations object to an ITransition.
 */
public class TransitionVisitor implements AnimationVisitor<ITransition> {

  double realTimeScalar;
  String shapeName;
  int dimNum;

  /**
   * The contructor for our TransitioinVisitor.
   * @param realTimeScalar scalar needed for the transistion toString.
   * @param shapeName name of the shape we are changing needed for the transition toString.
   */
  public TransitionVisitor(double realTimeScalar, String shapeName, int dimNum) {
    this.realTimeScalar = realTimeScalar;
    this.shapeName = shapeName;
    this.dimNum = dimNum;
  }

  /**
   * This method is used to adapt an IMoveAnimation to an ITransition.
   * @param move the move animation we are adding functionality to.
   * @return a new MoveTransitionAdapter which implements ITransition.
   */
  @Override
  public ITransition visit(IMoveAnimation move) {
    return new MoveTransitionAdapter(move, realTimeScalar,
            shapeName);
  }

  /**
   * This method is used to adapt an IScaleAnimation to an ITransition.
   * @param scale the scale animation we are adding functionality to.
   * @return a new SizeTransitionAdapter which implements ITransition.
   */
  @Override
  public ITransition visit(IScaleAnimation scale) {
    return new SizeTransitionAdapter(scale, realTimeScalar,
            shapeName, dimNum);
  }

  /**
   * This method is used to adapt an IColorAnimation to an ITransition.
   * @param changeColor the color animation we are adding functionality to.
   * @return a new SizeTransitionAdapter which implements ITransition.
   */
  @Override
  public ITransition visit(IColorAnimation changeColor) {
    return new ColorTransitionAdapter(changeColor, realTimeScalar,
            shapeName);
  }

}
