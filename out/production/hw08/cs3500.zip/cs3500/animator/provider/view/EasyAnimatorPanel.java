package cs3500.animator.provider.view;

import cs3500.animator.provider.model.IPosn;
import cs3500.animator.provider.model.IShape;
import cs3500.animator.provider.model.Color;
import java.awt.Graphics2D;
import java.awt.Graphics;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.util.HashMap;
import javax.swing.JPanel;

/**
 * This panel represents the region where the shapes of the easy animator are drawn.
 */
public class EasyAnimatorPanel extends JPanel {
  private HashMap<String, IShape> shapes;

  /**
   * Constructs a panel for the easy animator to be drawn.
   */
  public EasyAnimatorPanel(HashMap<String, IShape> shapes) {
    super();
    this.shapes = shapes;
  }

  /**
   * Sets which shapes this panel should show.
   *
   * @param shapes the shapes to show
   */
  public void setShapesToDraw(HashMap<String, IShape> shapes) {
    this.shapes = shapes;
  }

  @Override
  protected void paintComponent(Graphics g) {
    super.paintComponent(g);

    Graphics2D g2d = (Graphics2D) g;

    for (String name : this.shapes.keySet()) {
      IShape shape = this.shapes.get(name);


      IPosn position = shape.getPosition();
      double xPos = position.getX();
      double yPos = position.getY();
      double xLength;
      double yLength;

      Color shapeColor = shape.getColor();

      int r = (int) shapeColor.getRed();
      int green = (int) shapeColor.getGreen();
      int b = (int) shapeColor.getBlue();

      java.awt.Color drawColor = new java.awt.Color(r, green, b);

      // determine shape type and draw
      if (shape.getType() == IShape.Shapes.RECTANGLE) {
        xLength = shape.getXLength();
        yLength = shape.getYLength();

        //x pos and y pos are the lower left corner
        double upperLeftX = xPos;
        double upperLeftY = yPos;

        g2d.setColor(drawColor);
        g2d.fill(new Rectangle2D.Double(upperLeftX, upperLeftY, xLength, yLength));

      } else if (shape.getType() == IShape.Shapes.OVAL) {
        xLength = shape.getXLength() * 2;
        yLength = shape.getYLength() * 2;

        double upperLeftX = xPos - shape.getXLength();
        double upperLeftY = yPos - shape.getYLength();

        g2d.setColor(drawColor);
        g2d.fill(new Ellipse2D.Double(upperLeftX, upperLeftY, xLength, yLength));
      }
    }
  }


}
