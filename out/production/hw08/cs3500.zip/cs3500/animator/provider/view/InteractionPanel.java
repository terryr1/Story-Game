package cs3500.animator.provider.view;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.BorderFactory;

/**
 * Represents panel for the instructions as well as the text interaction.
 */
public class InteractionPanel extends JPanel {
  JButton submit;
  JTextField input;
  String consoleText;
  JLabel console;

  /**
   * Constructs a panel for the instructions and the text interaction.
   */
  public InteractionPanel() {
    super();

    this.setLayout(new BorderLayout());
    this.consoleText = "";

    // paragraph with instructions
    JLabel instructions = new JLabel();
    instructions.setText(this.getInstructions());

    // bump font size
    Font oldFont = instructions.getFont();
    instructions.setFont(new Font(oldFont.getName(), Font.PLAIN, 15));

    // make text appear in middle
    instructions.setHorizontalAlignment(SwingConstants.CENTER);

    this.add(instructions, BorderLayout.PAGE_START);

    // input field/button
    JPanel svgInput = new JPanel();

    this.input = new JTextField(15);
    svgInput.add(input);

    this.submit = new JButton("Export SVG");
    submit.setActionCommand("Export");
    svgInput.add(submit);

    this.add(svgInput);

    // add output message box
    this.console = new JLabel();
    console.setText("<html><b>Animator output:<b><br></html");
    console.setFont(new Font(oldFont.getName(), Font.PLAIN, 15));
    console.setHorizontalAlignment(SwingConstants.CENTER);
    console.setBorder(BorderFactory.createEmptyBorder(5, 10, 25, 10));
    this.add(console, BorderLayout.PAGE_END);
  }

  /**
   * Sets the text the console should display.
   *
   * @param s string to show
   */
  public void setConsoleText(String s) {
    String text = "<html><b>Animator output:</b><br>";
    text += s;
    text += "</html>";
    this.console.setText(text);
  }

  /**
   * Generates the instructions for using this animation in string html format.
   *
   * @return the string
   */
  private String getInstructions() {
    String result = "<html>";
    result += "<b>Controls</b>:<br>";
    result += "Press <b>p</b> to pause/play the animation.<br>";
    result += "Press <b>r</b> to restart the animation.<br>";
    result += "Press <b>l</b> to toggle looping of the animation.<br>";
    result += "Press the <b>up/down arrow keys</b> to speed up or slow down the animation.<br>";
    result += "When the animation is paused, <b>click</b> on shapes to select a subset to be " +
            "viewed.<br>";
    result += "Press <b>c</b> to clear selected shapes.<br>";
    result += "Enter a <b>file name</b> (without the .svg extension) to export current" +
            " animation.<br>";
    result += "</html>";
    return result;
  }

  /**
   * Gets the text currently in the text box.
   *
   * @return the text
   */
  public String getTextString() {
    return this.input.getText();
  }

  /**
   * Sets the text to show in the text field.
   *
   * @param s the string to set the box to
   */
  public void setTextString(String s) {
    this.input.setText(s);
  }

  /**
   * Sets the listener for the button of this panel.
   * @param listener the listener to give to the button
   */
  public void setButtonListener(ActionListener listener) {
    this.submit.addActionListener(listener);
  }
}
