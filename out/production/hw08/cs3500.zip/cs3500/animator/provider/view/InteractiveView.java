package cs3500.animator.provider.view;

import cs3500.animator.provider.model.IShape;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Container;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.HashMap;
import java.awt.BorderLayout;
import javax.swing.Timer;
import javax.swing.JFrame;

/**
 * Represents a hybrid view that offers interactive functionality. Allows a user to start, pause,
 * resume, restart, loop, change speed, and choose a subset of the available shapes on screen. Also
 * allows the user to choose to export the current on-screen animation to an SVG file.
 */
public class InteractiveView extends VisualView implements IInteractiveView {
  private boolean loopEnabled;
  private Timer timer;
  private int delay;
  private final double speedScalar;
  private MouseAdapter mouse;
  private HashMap<String, IShape> shapes;
  private HashMap<String, IShape> clickedShapes;
  private InteractionPanel interactionPanel;
  private int ticksPerSecond;
  private ActionListener buttonActionListener;

  /**
   * Constructs a new interactive view.
   */
  public InteractiveView() {
    super();
    this.loopEnabled = false;
    this.tickCount = 0;
    this.delay = 1;
    this.speedScalar = 0.5;
    this.clickedShapes = new HashMap<>();
    this.ticksPerSecond = 1;
  }

  /**
   * Produces a view of the shapes in this view.
   * @param shapes the shapes to draw
   * @param out where to send the output to
   * @param ticksPerSecond the speed to run the animation at
   */
  @Override
  public void render(HashMap<String, IShape> shapes, Appendable out, int ticksPerSecond) {
    this.shapes = shapes;
    this.setupFrame(shapes);
    double maxEndTime = this.getMaxEndTime(shapes);
    this.ticksPerSecond = ticksPerSecond;

    this.delay = (int) (1000 * (1 / (double) ticksPerSecond));
    ActionListener taskPerformer = new ActionListener() {
      public void actionPerformed(ActionEvent evt) {
        // every time timer goes off:

        // maybe loop
        if (loopEnabled && tickCount >= maxEndTime) {
          tickCount = 0;
        }

        // update shape state
        for (IShape shape : shapes.values()) {
          shape.stateAt(tickCount);
        }

        // refresh panel
        panel.repaint();

        // keep track of count
        tickCount += 1;
      }
    };

    // timer
    this.timer = new Timer(delay, taskPerformer);
    timer.setInitialDelay(delay);
  }

  /**
   * Finds the tick value of when the last shape disappears.
   *
   * @param shapes the shapes to check
   * @return the tick count
   */
  private double getMaxEndTime(HashMap<String, IShape> shapes) {
    double maxEndTime = 0;

    for (IShape shape : shapes.values()) {
      double shapeEndTime = shape.getEndTime();

      if (shapeEndTime > maxEndTime) {
        maxEndTime = shapeEndTime;
      }

    }

    return maxEndTime;
  }

  /**
   * Restarts this view.
   */
  @Override
  public void restart() {
    this.tickCount = 0;
    this.clearSelection();
    this.timer.restart();
    this.interactionPanel.setConsoleText("Restarted animation.");
  }

  /**
   * Toggles playing the animation.
   */
  @Override
  public void togglePlay() {
    if (this.timer.isRunning()) {
      this.timer.stop();
      this.interactionPanel.setConsoleText("Animation paused.");
    } else {
      this.timer.start();
      this.interactionPanel.setConsoleText("Animation started.");
    }
  }

  /**
   * Toggles looping the animation.
   */
  @Override
  public void toggleLoop() {
    if (loopEnabled) {
      this.interactionPanel.setConsoleText("Animation looping disabled.");
    } else {
      this.interactionPanel.setConsoleText("Animation looping enabled.");
    }
    this.loopEnabled = !this.loopEnabled;

  }

  /**
   * Increases speed of the animation.
   */
  @Override
  public void increaseSpeed() {
    this.delay = (int) ((1 - speedScalar) * this.delay);
    this.timer.setDelay(this.delay);
    this.interactionPanel.setConsoleText("Animation speed increased.");
  }

  /**
   * Decreases speed of the animation.
   */
  @Override
  public void decreaseSpeed() {
    this.delay = (int) ((1 + speedScalar) * this.delay);
    this.timer.setDelay(this.delay);
    this.interactionPanel.setConsoleText("Animation speed decreased.");
  }

  /**
   * Executes appropriate functionality when mouse is clicked.
   * @param event the mouse event associated with the mouse click.
   */
  @Override
  public void mouseClicked(MouseEvent event) {
    // if mouse is clicked on animation panel, make sure focus returns
    this.requestFocusInWindow();


    // can only clicked when paused
    if (this.timer.isRunning()) {
      return;
    }

    // check if clicked on actual shape
    String shapeName = this.nameOfClickedShape(event);
    if (shapeName == null) {
      return;
    }

    IShape shape = this.shapes.get(shapeName);
    // add to clicked shapes
    // cleared on 'r' for restart or 'c' for clear
    this.clickedShapes.put(shapeName, shape);

    // tell panel to only show clicked shapes
    // cleared on 'r' for restart or 'c' for clear
    this.panel.setShapesToDraw(clickedShapes);

    this.interactionPanel.setConsoleText("Clicked on " + shape.getType() + " " + shapeName + ".");

  }

  /**
   * Determines whether or not a shape was clicked.
   * @param event the mouse event to source the position of the click from
   * @return string name of the shape
   */
  private String nameOfClickedShape(MouseEvent event) {
    int mouseX = event.getX();
    int mouseY = event.getY();

    for (String name : this.shapes.keySet()) {
      IShape s = this.shapes.get(name);


      if (s.getType() == IShape.Shapes.OVAL) {
        int shapeCenterX = (int) s.getPosition().getX();
        int shapeCenterY = (int) s.getPosition().getY();

        double xRadius = s.getXLength();
        double yRadius = s.getYLength();

        double maxX = shapeCenterX + xRadius;
        double minX = shapeCenterX - xRadius;

        // check whether mouse click is within x range at all
        if (mouseX <= maxX && mouseX >= minX) {
          // if within x, check that also within y using general equation of an ellipse
          double fraction = Math.pow(mouseX - shapeCenterX, 2) / Math.pow(xRadius, 2);
          double valueUnderRadical = Math.pow(yRadius, 2) * (1 - fraction);
          double radicalResult = Math.sqrt(valueUnderRadical);
          double ellipseUpperY = radicalResult + shapeCenterY;
          double ellipseLowerY = (-1 * radicalResult) + shapeCenterY;

          if (mouseY <= ellipseUpperY && mouseY >= ellipseLowerY) {
            // clicked on an oval
            return name;
          }
        }

      } else if (s.getType() == IShape.Shapes.RECTANGLE) {
        int rectLowerLeftX = (int) s.getPosition().getX();
        int rectLowerLeftY = (int) s.getPosition().getY();

        double width = s.getXLength();
        double height = s.getYLength();

        double halfWidth = s.getXLength() / 2;
        double halfHeight = s.getYLength() / 2;

        double maxX = rectLowerLeftX + width;
        double minX = rectLowerLeftX;

        double maxY = rectLowerLeftY;
        double minY = rectLowerLeftY - height;

        boolean withinX = mouseX <= maxX && mouseX >= minX;
        boolean withinY = mouseY <= maxY && mouseY >= minY;

        if (withinX && withinY) {
          // clicked on a rectangle
          return name;
        }
      }
    }

    // didn't click on shape
    return null;
  }

  /**
   * Sets the mouse listenener for the shape panel.
   * @param mouse the listener
   */
  @Override
  public void setPanelMouseListener(MouseAdapter mouse) {
    this.mouse = mouse;
  }

  /**
   * Sets listener for events coming from submit button.
   * @param listener the listener
   */
  @Override
  public void setButtonListener(ActionListener listener) {
    this.buttonActionListener = listener;
  }

  /**
   * Exports current animation state to an SVG file.
   */
  @Override
  public void exportAnimation() {
    // get the file name
    String fileName = this.interactionPanel.getTextString();
    this.interactionPanel.setTextString("");

    // check file name valid
    if (fileName.equals("") || fileName.contains(".")) {
      this.interactionPanel.setConsoleText("Malformed file name. Please try again.");
    } else {
      HashMap<String, IShape> shapesToExport;

      // figure out whether to export all shapes or just a subset
      if (this.clickedShapes.isEmpty()) {
        shapesToExport = this.shapes;
      } else {
        shapesToExport = this.clickedShapes;
      }

      // setup file writer
      Appendable output = null;
      try {
        output = new PrintStream(fileName + ".svg");
      } catch (FileNotFoundException e) {
        System.out.println(e);
        this.interactionPanel.setConsoleText("Failed to output SVG.");
        return;
      }
      System.out.println(output);

      // print using appropriate svg view
      if (this.loopEnabled) {
        SVGView view = new LoopingSVGView();
        view.render(shapesToExport, output, ticksPerSecond);

      } else {
        SVGView view = new SVGView();
        view.render(shapesToExport, output, ticksPerSecond);
      }

      this.interactionPanel.setConsoleText("Animation written to " + fileName + ".svg");
    }
  }

  /**
   * If subset of shapes had been selected (clicked on), this method clears that selection.
   */
  @Override
  public void clearSelection() {
    this.clickedShapes = new HashMap<String, IShape>();
    this.panel.setShapesToDraw(shapes);
    this.interactionPanel.setConsoleText("Shape selection cleared.");
    this.repaint();
  }

  /**
   * Creates the frame for the animation.
   * @param shapes - the shapes we are animating.
   */
  @Override
  protected void setupFrame(HashMap<String, IShape> shapes) {
    this.setTitle("EasyAnimation");
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setResizable(true);
    this.setSize(900, 900);

    // set to border layout
    Container pane = this.getContentPane();
    pane.setLayout(new BorderLayout());

    // add animation panel
    this.panel = new EasyAnimatorPanel(shapes);
    panel.addMouseListener(mouse);
    pane.add(panel);

    // add instructions panel
    this.interactionPanel = new InteractionPanel();
    this.interactionPanel.setButtonListener(buttonActionListener);


    pane.add(interactionPanel, BorderLayout.PAGE_END);

    this.setVisible(true);
    this.requestFocusInWindow();
  }
}

