package cs3500.animator.provider.view;

import java.io.IOException;
import java.io.StringWriter;
import java.util.HashMap;

import cs3500.animator.provider.model.IShape;

/**
 * Represents an SVG view that is enabled to loop for an animation.
 */
public class LoopingSVGView extends SVGView {

  /**
   * Constructs a looping SVG view.
   */
  public LoopingSVGView() {
    super();
  }

  @Override
  public void render(HashMap<String, IShape> shapes, Appendable out, int ticksPerSecond) {
    // get the super svg string
    Appendable writer = new StringWriter();
    super.render(shapes, writer, ticksPerSecond);
    String result = writer.toString();

    double scalarToRealTime = 1 / (double) ticksPerSecond;

    // get max end time
    double maxEndTime = this.getMaxEndTime(shapes) * scalarToRealTime * 1000;

    // parse the super's string to add fake rectangle for looping
    String resultWithFakeRectangle = addFakeRectangle(result, maxEndTime);

    try {
      out.append(resultWithFakeRectangle);
    } catch (IOException e) {
      // could not append
    }
  }

  /**
   * Format the string value of the given start time.
   *
   * @param startTime the time this animation starts at.
   * @return a string for the begin attribute of SVG
   */
  @Override
  protected String formatBeginTime(Double startTime) {
    return "base.begin+" + startTime;

  }

  /**
   * Adds a fake rectangle to be used as a time reference for looping.
   *
   * @param svgResult  the already formatted svg to insert the rectangle into
   * @param maxEndTime when the animation should finish and loop
   * @return the svg with the fake rectangle insereted
   */
  private String addFakeRectangle(String svgResult, double maxEndTime) {
    int index = 0;
    StringBuilder stringBuilder = new StringBuilder();

    // get the part of the SVG file before the first shape.
    String firstCloseBracket = ">";
    int firstCloseBracketIndex = svgResult.indexOf(firstCloseBracket);

    String startFile = svgResult.substring(0, firstCloseBracketIndex + 1);
    stringBuilder.append(startFile);

    // add a fake rectangle for time looping reference.
    String fakeRectangle = "<rect> \n" + "<animate id=\"base\" begin=\"0;base.end\" "
            + "dur=\"" + maxEndTime + "ms\" " + "attributeName=\"visibility\" from=\"hide\" "
            + "to=\"hide\"/>\n" + "</rect>";
    stringBuilder.append(fakeRectangle);

    // get the part of the file with the shapes.
    String endFile = svgResult.substring(firstCloseBracketIndex + 1);
    stringBuilder.append(endFile);

    String resultWithFakeRectangle = stringBuilder.toString();

    return resultWithFakeRectangle;
  }

  /**
   * Formats the transition (animation) tags of the shape.
   *
   * @param shape            the shape to get the transitions from
   * @param scalarToRealTime scalar to convert ticks to real seconds
   * @return the string svg representation
   */
  @Override
  protected String formatTransitionSVG(IShape shape, double scalarToRealTime) {
    String transitions = super.formatTransitionSVG(shape, scalarToRealTime);

    HashMap<String, Double> shapeAttributes = new HashMap<>();
    if (shape.getType() == IShape.Shapes.RECTANGLE) {
      shapeAttributes.put("x", shape.getPosition().getX());
      shapeAttributes.put("y", shape.getPosition().getY());
      shapeAttributes.put("width", shape.getXLength());
      shapeAttributes.put("height", shape.getYLength());
    } else if (shape.getType() == IShape.Shapes.OVAL) {
      shapeAttributes.put("cx", shape.getPosition().getX());
      shapeAttributes.put("cy", shape.getPosition().getY());
      shapeAttributes.put("rx", shape.getXLength());
      shapeAttributes.put("ry", shape.getYLength());
    }

    String loopingAttributes = "";
    for (String attribute : shapeAttributes.keySet()) {
      Double value = shapeAttributes.get(attribute);

      loopingAttributes += "<animate attributeType=\"xml\" begin=\"base.end\" dur=\""
              + "1ms\"" + " attributeName=\"" + attribute + "\" to=\"" + value + "\" " +
              "fill=\"freeze\"/>\n";
    }

    return transitions + loopingAttributes;
  }

  /**
   * Finds the tick value of when the last shape disappears.
   *
   * @param shapes the shapes to check
   * @return the tick count
   */
  private double getMaxEndTime(HashMap<String, IShape> shapes) {
    double maxEndTime = 0;

    for (IShape shape : shapes.values()) {
      double shapeEndTime = shape.getEndTime();

      if (shapeEndTime > maxEndTime) {
        maxEndTime = shapeEndTime;
      }

    }

    return maxEndTime;
  }

}
