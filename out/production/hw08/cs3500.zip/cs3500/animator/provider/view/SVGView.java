package cs3500.animator.provider.view;

import java.io.IOException;
import java.util.HashMap;
import cs3500.animator.provider.model.IColor;
import cs3500.animator.provider.model.IColorTransition;
import cs3500.animator.provider.model.IMoveTransition;
import cs3500.animator.provider.model.ISizeTransition;
import cs3500.animator.provider.model.ITransition;
import cs3500.animator.provider.model.IPosn;
import cs3500.animator.provider.model.IShape;

/**
 * Represents an SVG view of an animation.
 */
public class SVGView implements IAnimationView {


  /**
   * Produces a view of the shapes in this view.
   * @param shapes the shapes to draw
   * @param out where to send the output to
   * @param ticksPerSecond the speed to run the animation at
   */
  @Override
  public void render(HashMap<String, IShape> shapes, Appendable out, int ticksPerSecond) {
    double scalarToRealTime = 1 / (double) ticksPerSecond;

    String output = "<svg width=\"100%\" height=\"100%\" version=\"1.1\" " +
            "xmlns=\"http://www.w3.org/2000/svg\">\n";

    for (String name : shapes.keySet()) {
      IShape shape = shapes.get(name);

      output += this.formatSVG(name, shape, scalarToRealTime);
    }

    output += "</svg>";

    try {
      out.append(output);
    } catch (IOException e) {
      // Failed to output.
    }
  }

  /**
   * Formats the SVG tag of this shape.
   *
   * @param name             the name of the shape
   * @param shape            the shape to format
   * @param scalarToRealTime scalar to convert ticks to seconds
   * @return the string svg
   */
  private String formatSVG(String name, IShape shape, double scalarToRealTime) {
    String openTag = "";
    String tagName = "";
    String xPosName = "";
    String yPosName = "";
    String xDimName = "";
    String yDimName = "";

    if (shape.getType() == IShape.Shapes.RECTANGLE) {
      tagName = "rect";
      xPosName = "x";
      yPosName = "y";
      xDimName = "width";
      yDimName = "height";
    } else if (shape.getType() == IShape.Shapes.OVAL) {
      tagName = "ellipse";
      xPosName = "cx";
      yPosName = "cy";
      xDimName = "rx";
      yDimName = "ry";
    }

    openTag += "<" + tagName + " id=\"" + name + "\" " + xPosName + "=\""
            + shape.getPosition().getX() + "\" " + yPosName + "=\""
            + shape.getPosition().getY() + "\" ";
    openTag += xDimName + "=\"" + shape.getXLength() + "\" " + yDimName + "=\""
            + shape.getYLength() + "\" ";
    openTag += "fill=\"rgb(" + (int) shape.getColor().getRed() + ","
            + (int) shape.getColor().getGreen() + ","
            + (int) shape.getColor().getBlue() + ")\" ";
    openTag += "visibility=\"hidden\">\n";

    double startTime = Math.round(shape.getStartTime() * scalarToRealTime * 1000);
    double endTime = shape.getEndTime() * scalarToRealTime * 1000;
    double dur = 1;//Math.round(endTime - startTime);

    String visibilityOn = "<animate attributeType=\"xml\" begin=\"" +
            this.formatBeginTime(startTime)
            + "ms\" dur=\""
            + dur + "ms\" " + "attributeName=\"visibility\" " +
            "from=\"hidden\" to=\"visible\" fill=\"freeze\"/>\n";

    String visibilityOff = "<animate attributeType=\"xml\" begin=\"" + this.formatBeginTime(endTime)
            + "ms\" dur=\""
            + dur + "ms\" " + "attributeName=\"visibility\" " +
            "from=\"visible\" to=\"hidden\" fill=\"freeze\"/>\n";


    String animations = this.formatTransitionSVG(shape, scalarToRealTime);


    String closeTag = "</" + tagName + ">";

    return openTag + visibilityOn + visibilityOff + animations + closeTag;
  }


  /**
   * Formats the transition (animation) tags of the shape.
   *
   * @param shape            the shape to get the transitions from
   * @param scalarToRealTime scalar to convert ticks to real seconds
   * @return the string svg representation
   */
  protected String formatTransitionSVG(IShape shape, double scalarToRealTime) {
    IShape.Shapes type = shape.getType();
    String res = "";
    for (ITransition t : shape.getTransitions()) {
      double startTimeNum = Math.round(t.getStartTime() * scalarToRealTime * 1000);
      String startTime = this.formatBeginTime(startTimeNum);
      double endTime = t.getEndTime() * scalarToRealTime * 1000;
      double dur = Math.round(endTime - startTimeNum);

      String startValue;
      String endValue;
      String attributeName;

      if (t.getType() == ITransition.Transitions.COLOR) {
        IColorTransition colorTrans = (IColorTransition) t;

        IColor fromColor = colorTrans.getFromColor();
        IColor toColor = colorTrans.getToColor();

        startValue = "rgb(" + (int) fromColor.getRed() + "," + (int) fromColor.getGreen() + ","
                + (int) fromColor.getBlue() + ")";
        endValue = "rgb(" + (int) toColor.getRed() + "," + (int) toColor.getGreen() + ","
                + (int) toColor.getBlue() + ")";

        attributeName = "fill";
        res += "<animate attributeType=\"xml\" begin=\"" + startTime + "ms\" " +
                "dur=\"" + dur + "ms\" attributeName=\"" + attributeName + "\" from=\""
                + startValue + "\" " + "to=\"" + endValue + "\" fill=\"freeze\"/>\n";

      } else if (t.getType() == ITransition.Transitions.MOVE) {
        IMoveTransition moveTrans = (IMoveTransition) t;

        IPosn from = moveTrans.getFromPosn();
        IPosn to = moveTrans.getToPosn();

        double startX = from.getX();
        double startY = from.getY();
        double endX = to.getX();
        double endY = to.getY();

        String xPosName = "";
        String yPosName = "";
        if (type == IShape.Shapes.RECTANGLE) {
          xPosName = "x";
          yPosName = "y";
        } else if (type == IShape.Shapes.OVAL) {
          xPosName = "cx";
          yPosName = "cy";
        }

        String result = "";
        if (startX != endX) {
          res += "<animate attributeType=\"xml\" begin=\"" + startTime + "ms\" dur=\"" + dur
                  + "ms\"" + " attributeName=\"" + xPosName + "\" from=\"" + startX + "\" " +
                  "to=\"" + endX + "\" fill=\"freeze\"/>\n";
        }

        if (startY != endY) {
          res += "<animate attributeType=\"xml\" begin=\"" + startTime + "ms\" dur=\"" + dur
                  + "ms\"" + " attributeName=\"" + yPosName + "\" from=\"" + startY + "\" " +
                  "to=\"" + endY + "\" fill=\"freeze\"/>\n";
        }


      } else if (t.getType() == ITransition.Transitions.RESIZE) {
        ISizeTransition sizeTrans = (ISizeTransition) t;

        startValue = "" + sizeTrans.getStartValue();
        endValue = "" + sizeTrans.getEndValue();

        attributeName = "";
        if (type == IShape.Shapes.RECTANGLE) {
          if (sizeTrans.getDimensionName().equals("Width")) {
            attributeName = "width";
          } else {
            attributeName = "height";
          }
        } else if (type == IShape.Shapes.OVAL) {
          if (sizeTrans.getDimensionName().equals("X Radius")) {
            attributeName = "rx";
          } else {
            attributeName = "ry";
          }
        }

        res += "<animate attributeType=\"xml\" begin=\"" + startTime + "ms\" " +
                "dur=\"" + dur + "ms\" attributeName=\"" + attributeName + "\" from=\""
                + startValue + "\" " + "to=\"" + endValue + "\" fill=\"freeze\"/>\n";
      }
    }

    return res;
  }

  /**
   * Format the string value of the given start time.
   *
   * @param startTime the time this animation starts at.
   * @return a string for the begin attribute of SVG
   */
  protected String formatBeginTime(Double startTime) {
    return startTime.toString();
  }
}
