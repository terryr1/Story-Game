package cs3500.animator.provider.view;

import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * View interface for views that handle user inputs, such as keyboard presses.
 */
public interface IInteractiveView extends IAnimationView {

  /**
   * Restarts this view.
   */
  void restart();

  /**
   * Toggles playing the animation.
   */
  void togglePlay();

  /**
   * Toggles looping the animation.
   */
  void toggleLoop();

  /**
   * Increases speed of the animation.
   */
  void increaseSpeed();

  /**
   * Decreases speed of the animation.
   */
  void decreaseSpeed();

  /**
   * Executes appropriate functionality when mouse is clicked.
   * @param event the mouse event associated with the mouse click.
   */
  void mouseClicked(MouseEvent event);

  /**
   * Sets the mouse listenener for the shape panel.
   * @param mouse the listener
   */
  void setPanelMouseListener(MouseAdapter mouse);

  /**
   * Sets listener for events coming from submit button.
   * @param l the listener
   */
  void setButtonListener(ActionListener l);

  /**
   * Exports current animation state to an SVG file.
   */
  void exportAnimation();

  /**
   * If subset of shapes had been selected (clicked on), this method clears that selection.
   */
  void clearSelection();

}
