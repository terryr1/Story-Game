package cs3500.animator.provider.view;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import cs3500.animator.provider.model.IShape;

/**
 * Represents a test (string) view of an animation.
 */
public class TextView implements IAnimationView {

  /**
   * Constructs a TextView.
   */
  public TextView() {
    // empty
  }

  /**
   * Produces a view of the shapes in this view.
   * @param shapesMap the shapes to draw
   * @param out where to send the output to
   * @param ticksPerSecond the speed to run the animation at
   */
  @Override
  public void render(HashMap<String, IShape> shapesMap, Appendable out, int ticksPerSecond) {
    Collection<IShape> shapes = shapesMap.values();

    // safe cast since it's an int to a double
    double scalar = 1 / (double) ticksPerSecond;

    if (shapes.size() <= 0) {
      try {
        out.append("No shapes in this animation.");
      } catch (IOException e) {
        // Output failed.
      }
    }

    else {
      // summarize shapes
      String shapesString = "Shapes:\n";
      for (String name : shapesMap.keySet()) {
        IShape shape = shapesMap.get(name);

        shapesString += "Name: " + name + "\n";
        shape.setScalarToRealTime(scalar);
        shapesString += shape.toString();
        shapesString += "\n\n";
      }

      // summarize transitions
      List<String> transitionStrings = new ArrayList<>();
      for (String name : shapesMap.keySet()) {
        IShape shape = shapesMap.get(name);

        for (String transition : shape.transitionSummary()) {
          // add every transition statement for this shape named "name"
          String toAdd = "Shape " + name + " " + transition;
          transitionStrings.add(toAdd);
        }
      }

      transitionStrings.sort(new TransitionComparator());

      String transitionsFormatted = "";
      for (String s : transitionStrings) {
        transitionsFormatted += s + "\n";
      }

      try {
        out.append(shapesString + transitionsFormatted);
      } catch (IOException e) {
        // Failed to output.
      }

    }
  }
}
