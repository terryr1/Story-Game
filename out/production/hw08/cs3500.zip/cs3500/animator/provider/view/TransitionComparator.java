package cs3500.animator.provider.view;

import java.util.Comparator;

/**
 * Compares transition statements based on when they occur.
 */
public class TransitionComparator implements Comparator<String> {

  /**
   * Compares the given Stings.
   * @param o1 the first string we are comparing.
   * @param o2 the second string we are comparing.
   * @return returns true if the first string's start time comes before the second string's.
   */
  @Override
  public int compare(String o1, String o2) {
    double time1 = this.startTimeOf(o1);
    double time2 = this.startTimeOf(o2);

    if (time1 < time2) {
      return -1;
    } else if (time1 > time2) {
      return 1;
    } else {
      return 0;
    }
  }

  /**
   * Finds the value of the first t= in the string expression.
   * @param str the string to find the start time in
   * @return the time value as an integer
   */
  private double startTimeOf(String str) {
    int tIndex = str.indexOf("=");
    String timeFirstThingInString = str.substring(tIndex + 1);
    String startTimeAsString = timeFirstThingInString.split("s")[0];
    double time = Double.parseDouble(startTimeAsString);

    return time;
  }
}
