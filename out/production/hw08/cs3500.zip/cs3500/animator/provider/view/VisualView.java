package cs3500.animator.provider.view;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.Timer;
import cs3500.animator.provider.model.IShape;

/**
 * This is an implementation of the IAnimationView interface
 * that uses Java Swing library to draw the results of the
 * simple shape animation. It shows any error messages using a
 * pop-up dialog box.
 */
public class VisualView extends JFrame implements IAnimationView {
  protected EasyAnimatorPanel panel;
  protected int tickCount;

  /**
   * Constructs an easy animator animation view.
   */
  public VisualView() {
    super();
    this.tickCount = 0;
  }

  /**
   * Produces a view of the shapes in this view.
   * @param shapes the shapes to draw
   * @param out where to send the output to
   * @param ticksPerSecond the speed to run the animation at
   */
  @Override
  public void render(HashMap<String, IShape> shapes, Appendable out, int ticksPerSecond) {
    this.setupFrame(shapes);
    // for every timer event
    // loop through shapes and update state
    // scrollPanel.repaint()

    int  delay = (int) (1000 * (1 / (double) ticksPerSecond));
    ActionListener taskPerformer = new ActionListener() {
      int tickCount = 0;

      public void actionPerformed(ActionEvent evt) {
        // every time timer goes off:
        // update shape state
        for (IShape shape : shapes.values()) {
          shape.stateAt(tickCount);
        }

        // refresh panel
        panel.repaint();

        // keep track of count
        tickCount += 1;
      }
    };

    // start timer
    new Timer(delay, taskPerformer).start();

    // break condition?
  }

  /**
   * Creates the frame for the animation.
   * @param shapes - the shapes we are animating.
   */
  protected void setupFrame(HashMap<String, IShape> shapes) {

    this.setTitle("EasyAnimation");
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setResizable(true);
    this.setLayout(new BorderLayout());

    this.panel = new EasyAnimatorPanel(shapes);
    JScrollPane scrollPanel = new JScrollPane(panel,
            JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
            JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);

    this.setSize(750, 750);

    this.add(scrollPanel, BorderLayout.CENTER);

    this.setVisible(true);
  }
}
