package cs3500.animator.provider.view;

import cs3500.animator.provider.model.IShape;
import java.util.HashMap;

/**
 * Defines the interface for producing a view of the animation's shapes.
 */
public interface IAnimationView {

  /**
   * Produces a view of the shapes in this view.
   * @param shapes the shapes to draw
   * @param out where to send the output to
   * @param ticksPerSecond the speed to run the animation at
   */
  public void render(HashMap<String, IShape> shapes, Appendable out, int ticksPerSecond);

}
