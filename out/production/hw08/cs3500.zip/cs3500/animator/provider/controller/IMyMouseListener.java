package cs3500.animator.provider.controller;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

/**
 * Represents the functionality of a MyMouseListener.
 */
public interface IMyMouseListener extends MouseListener {

  /**
   * Sets this runnable to be the class's runnable.
   * @param runnable the given runnable object.
   */
  void setRunnable(MouseRunnable runnable);

  /**
   * Runs the runnable if the mouse is clicked.
   * @param event the event which occured when the mouse was clicked.
   */
  @Override
  void mouseClicked(MouseEvent event);


}
