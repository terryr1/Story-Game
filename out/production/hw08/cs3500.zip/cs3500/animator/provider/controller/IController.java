package cs3500.animator.provider.controller;

/**
 * Interface for a controller in the EasyAnimator.
 */
public interface IController {

  /**
   * Gets data from model and gives it to view to be rendered.
   */
  void start();

}
