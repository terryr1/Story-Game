package cs3500.animator.provider.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.util.HashMap;
import java.util.LinkedHashMap;
import cs3500.animator.model.AnimatorModelOperations;
import cs3500.animator.model.shapes.ShapeOperations;
import cs3500.animator.provider.model.IShape;
import cs3500.animator.provider.model.ShapeAdapter;
import cs3500.animator.provider.view.InteractiveView;

/**
 * The controller for an InteractiveView and AnimatorModelOperations model. This controller
 * controls all the functionality which is available to a user to modify the view.
 */
public class ProviderController implements IController, KeyListener, ActionListener {

  private final AnimatorModelOperations model;
  private final InteractiveView view;
  private final MyMouseListener mouseListener;
  private int ticksPerSecond;
  private final HashMap<String, IShape> stateMap;

  /**
   * The constructor used to construct a ProviderController.
   * The animator implementation we revieved must have a controlloer which takes an InteractiveView
   * rather than the interface in order to add a keylistener.
   * @param model the model for our controller.
   * @param view the view used in our controller.
   * @param ticksPerSecond the ticks per second to start our view at.
   */
  public ProviderController(AnimatorModelOperations model, InteractiveView view,
                            int ticksPerSecond) {
    this.model = model;
    this.view = view;
    this.mouseListener = new MyMouseListener();
    this.ticksPerSecond = ticksPerSecond;
    this.stateMap = new LinkedHashMap<>();

    for (ShapeOperations s: model.getState()) {
      ShapeAdapter sa = new ShapeAdapter(s);
      stateMap.put(s.getName(), sa);
    }
  }

  /**
   * Gets data from model and gives it to view to be rendered.
   */
  @Override
  public void start() {

    for (ShapeOperations s: model.getState()) {
      ShapeAdapter sa = new ShapeAdapter(s);
      stateMap.put(s.getName(), sa);
    }
    view.setButtonListener(this);
    mouseListener.setRunnable(new MouseClick());
    view.setPanelMouseListener(mouseListener);
    view.addKeyListener(this);
    Appendable ap = new StringBuilder();
    view.render(stateMap, ap, ticksPerSecond);
  }

  /**
   * The MouseRunnable class which handles our mouse click events to take out shapes from
   * the animation.
   */
  private class MouseClick implements MouseRunnable {

    /**
     * If a MouseClick occurs, run the view mouse clicked method.
     * @param event the given mouse event.
     */
    @Override
    public void run(MouseEvent event) {
      view.mouseClicked(event);
    }

  }

  /**
   * Method that's called when a key is typed, not used.
   * @param e the event which occured.
   */
  @Override
  public void keyTyped(KeyEvent e) {
    //not needed.
  }

  /**
   * Method that's called when a key is pressed, not used.
   * @param e the event which occured.
   */
  @Override
  public void keyPressed(KeyEvent e) {
    //not needed.
  }

  /**
   * Method that's called when a key is released, calls the appropriate method in the view.
   * @param e the event which occured.
   */
  @Override
  public void keyReleased(KeyEvent e) {
    switch (e.getKeyCode()) {
      case KeyEvent.VK_P: {
        view.togglePlay();
        return;
      }
      case KeyEvent.VK_R: {
        view.restart();
        return;
      }
      case KeyEvent.VK_L: {
        view.toggleLoop();
        return;
      }
      case KeyEvent.VK_C: {
        view.clearSelection();
        return;
      }
      case KeyEvent.VK_UP: {
        this.ticksPerSecond++;
        view.increaseSpeed();
        return;
      }
      case KeyEvent.VK_DOWN: {
        this.ticksPerSecond--;
        view.decreaseSpeed();
        return;
      }
      default: {
        //dont need a default case.
        return;
      }
    }
  }

  /**
   * This method is used if a button is pressed in the view, it calls the method in the view
   * which needs to occur when that button is pressed.
   * @param e the event which has occurred.
   */
  @Override
  public void actionPerformed(ActionEvent e) {
    if (e.getActionCommand().equals("Export")) {
      view.exportAnimation();
    }
  }

}
