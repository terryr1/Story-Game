package cs3500.animator.provider.controller;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * A class to represent a mouse listener that finds and operates on mouse events.
 */
public class MyMouseListener extends MouseAdapter implements IMyMouseListener {
  private MouseRunnable runnable;

  /**
   * Constructs a MouseListener.
   */
  public MyMouseListener() {
    // empty constructor.
  }

  /**
   * Sets this runnable to be the class's runnable.
   * @param runnable the given runnable object.
   */
  @Override
  public void setRunnable(MouseRunnable runnable) {
    this.runnable = runnable;
  }

  /**
   * Runs the runnable if the mouse is clicked.
   * @param event the event which occured when the mouse was clicked.
   */
  @Override
  public void mouseClicked(MouseEvent event) {
    this.runnable.run(event);
  }

}
