package cs3500.animator.provider.controller;

import java.awt.event.MouseEvent;

/**
 * Interface for a runnable that can take a mouse event.
 */
public interface MouseRunnable {

  /**
   * The run method that can take a mouse event. Runs the runnable operation.
   * @param event the given mouse event.
   */
  void run(MouseEvent event);

}
